idf_component_register(SRCS "contador_pessoas.c" "web_stream.c"
                       INCLUDE_DIRS ".")