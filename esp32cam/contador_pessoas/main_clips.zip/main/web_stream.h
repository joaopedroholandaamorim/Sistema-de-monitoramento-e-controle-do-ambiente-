#pragma once
void wifi_init_sta(void);      // bloqueia até obter IP
void start_webserver(void);    // porta 80 (/ e /capture) e 81 (/stream)