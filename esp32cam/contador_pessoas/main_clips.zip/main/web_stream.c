#include <string.h>
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_timer.h"
#include "esp_netif.h"
#include "esp_http_server.h"
#include "esp_camera.h"
#include "img_converters.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "web_stream.h"

#define WIFI_SSID "ContadorCam"
#define WIFI_PASS "12345678"

static const char *TAG = "web";
static EventGroupHandle_t s_wifi_eg;
#define GOT_IP_BIT BIT0

#define PART_BOUNDARY "123456789000000000000987654321"
static const char *STREAM_CT   = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char *STREAM_BND  = "\r\n--" PART_BOUNDARY "\r\n";
static const char *STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

/* ---------------- Wi-Fi ---------------- */
static void wifi_evt(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        xEventGroupClearBits(s_wifi_eg, GOT_IP_BIT);
        ESP_LOGW(TAG, "Wi-Fi caiu, reconectando...");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "IP obtido: " IPSTR "  -> abra http://" IPSTR "/", IP2STR(&e->ip_info.ip), IP2STR(&e->ip_info.ip));
        xEventGroupSetBits(s_wifi_eg, GOT_IP_BIT);
    }
}

void wifi_init_sta(void)
{
    s_wifi_eg = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_evt, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_evt, NULL));

    wifi_config_t wc = { 0 };
    strncpy((char *)wc.sta.ssid, WIFI_SSID, sizeof(wc.sta.ssid) - 1);
    strncpy((char *)wc.sta.password, WIFI_PASS, sizeof(wc.sta.password) - 1);
    wc.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wc));
    ESP_ERROR_CHECK(esp_wifi_start());
    esp_wifi_set_ps(WIFI_PS_NONE);   // menos latência

    xEventGroupWaitBits(s_wifi_eg, GOT_IP_BIT, pdFALSE, pdTRUE, portMAX_DELAY);
}

/* ---------------- HTTP handlers ---------------- */
static esp_err_t index_handler(httpd_req_t *req)
{
    static const char html[] =
    "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>Contador</title></head><body style='background:#111;color:#eee;font-family:sans-serif;text-align:center'>"
    "<h3>ESP32-CAM</h3>"
    "<div style='position:relative;display:inline-block;width:100%;max-width:640px'>"
    "<img id='s' style='width:100%;image-rendering:pixelated;display:block'>"
    /* Linha horizontal verde (limite da porta) */
    //"<div style='position:absolute;left:0;right:0;top:40%;border-top:2px solid #0f0'></div>"
    /* Linha horizontal branca (confirmação) */
    //"<div style='position:absolute;left:0;right:0;top:60%;border-top:2px solid #fff'></div>"
    /* Linha diagonal em ciano (do topo esquerdo até a parte inferior direita) */
    "<svg style='position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none'>"
    "<line x1='0%' y1='0%' x2='100%' y2='100%' stroke='#0ff' stroke-width='2' />"
    "</svg>"
    "</div>"
    "<p><a style='color:#8cf' href='/capture'>/capture (foto unica)</a></p>"
    "<script>document.getElementById('s').src=location.protocol+'//'+location.hostname+':81/stream';</script>"
    "</body></html>";
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, html, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t capture_handler(httpd_req_t *req)
{
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) { httpd_resp_send_500(req); return ESP_FAIL; }

    uint8_t *jpg = NULL; size_t len = 0;
    bool ok = frame2jpg(fb, 80, &jpg, &len);   // grayscale -> JPEG so para visualizar
    esp_camera_fb_return(fb);
    if (!ok) { httpd_resp_send_500(req); return ESP_FAIL; }

    httpd_resp_set_type(req, "image/jpeg");
    esp_err_t r = httpd_resp_send(req, (const char *)jpg, len);
    free(jpg);
    return r;
}

static esp_err_t stream_handler(httpd_req_t *req)
{
    esp_err_t res = httpd_resp_set_type(req, STREAM_CT);
    if (res != ESP_OK) return res;
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

    char part[64];
    int64_t t0 = esp_timer_get_time();
    int frames = 0;

    while (true) {
        camera_fb_t *fb = esp_camera_fb_get();
        if (!fb) { res = ESP_FAIL; break; }

        uint8_t *jpg = NULL; size_t len = 0;
        bool ok = frame2jpg(fb, 60, &jpg, &len);
        esp_camera_fb_return(fb);
        if (!ok) { res = ESP_FAIL; break; }

        res = httpd_resp_send_chunk(req, STREAM_BND, strlen(STREAM_BND));
        if (res == ESP_OK) {
            size_t h = snprintf(part, sizeof(part), STREAM_PART, (unsigned)len);
            res = httpd_resp_send_chunk(req, part, h);
        }
        if (res == ESP_OK) res = httpd_resp_send_chunk(req, (const char *)jpg, len);
        free(jpg);
        if (res != ESP_OK) break;   // cliente fechou a aba

        if (++frames % 30 == 0) {
            int64_t now = esp_timer_get_time();
            ESP_LOGI(TAG, "stream: %.1f fps", 30.0f * 1e6f / (float)(now - t0));
            t0 = now;
        }
    }
    return res;
}

void start_webserver(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.stack_size = 8192;

    httpd_uri_t u_index   = { .uri = "/",        .method = HTTP_GET, .handler = index_handler };
    httpd_uri_t u_capture = { .uri = "/capture", .method = HTTP_GET, .handler = capture_handler };
    httpd_handle_t srv = NULL;
    if (httpd_start(&srv, &cfg) == ESP_OK) {
        httpd_register_uri_handler(srv, &u_index);
        httpd_register_uri_handler(srv, &u_capture);
    }

    // servidor separado para o stream (porta 81)
    cfg.server_port += 1;
    cfg.ctrl_port   += 1;
    httpd_uri_t u_stream = { .uri = "/stream", .method = HTTP_GET, .handler = stream_handler };
    httpd_handle_t srv2 = NULL;
    if (httpd_start(&srv2, &cfg) == ESP_OK) {
        httpd_register_uri_handler(srv2, &u_stream);
    }
}